<?php
return require MODX_CORE_PATH.'components/begateway/begateway.inc.php';
